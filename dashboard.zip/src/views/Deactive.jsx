import React from 'react';

const Deactive = () => {
    return (
        <div>
            Deaktivált eladó
        </div>
    );
};

export default Deactive;