import React from 'react';

const Pending = () => {
    return (
        <div>
            Függőben lévő eladó
        </div>
    );
};

export default Pending;