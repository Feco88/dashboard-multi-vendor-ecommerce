import React from 'react';

const UnAuthorized = () => {
    return (
        <div>
            <h1>Jogosulatlan hozzáférés</h1>
        </div>
    );
};

export default UnAuthorized;
